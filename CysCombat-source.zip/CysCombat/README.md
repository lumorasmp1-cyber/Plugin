# CysCombat

Plugin custom untuk LumoraSMP (EcoCPVP Practice) yang mengatur damage dan knockback
untuk End Crystal dan Respawn Anchor secara presisi, dengan dukungan Folia.

## Cara build via GitHub (tanpa laptop)

1. Buat repo baru di GitHub, misal `CysCombat`.
2. Upload semua file di folder ini ke repo (lewat GitHub web/app di HP: tombol "Add file" -> "Upload files").
   Pastikan struktur foldernya tetap sama persis:
   ```
   .github/workflows/build.yml
   src/main/java/com/lumorasmp/cyscombat/CysCombat.java
   src/main/java/com/lumorasmp/cyscombat/CombatListener.java
   src/main/java/com/lumorasmp/cyscombat/ReloadCommand.java
   src/main/resources/plugin.yml
   src/main/resources/config.yml
   pom.xml
   ```
3. Setelah file ter-upload dan ter-commit ke branch `main`, buka tab **Actions** di repo.
4. Workflow "Build CysCombat" akan otomatis jalan. Tunggu sampai tanda centang hijau muncul (~1-2 menit).
5. Klik workflow run yang selesai -> scroll ke bawah ke bagian **Artifacts** -> download `CysCombat-jar`.
6. Extract zip-nya, dapat file `CysCombat-1.0.0.jar`.

## Instalasi di server

1. Upload `CysCombat-1.0.0.jar` ke folder `plugins/` di server Folia lo.
2. Restart server (bukan reload, karena plugin baru).
3. Cek console, harus muncul: `CysCombat enabled. Folia-supported: true`
4. Edit `plugins/CysCombat/config.yml` sesuai kebutuhan (damage, knockback horizontal/vertical).
5. Reload config tanpa restart: `/cyscombat reload`

## Konfigurasi

Lihat `config.yml` - semua angka damage dan knockback bisa diubah tanpa compile ulang.

## Catatan teknis

- Plugin ini mendeteksi End Crystal lewat `EntityDamageByEntityEvent` (damager instanceof EnderCrystal).
- Plugin ini mendeteksi Respawn Anchor/Bed lewat `EntityDamageByBlockEvent`, dengan verifikasi
  tipe block (`RESPAWN_ANCHOR` atau `*_BED`) agar tidak salah kena ledakan TNT yang juga
  menghasilkan cause `BLOCK_EXPLOSION`.
- Velocity di-set langsung di dalam event handler tanpa scheduler tambahan, karena event
  damage selalu dijalankan di region thread yang sudah benar (sesuai dokumentasi Folia).
- `folia-supported: true` di-set di plugin.yml, syarat wajib agar Folia mau memuat plugin ini.
