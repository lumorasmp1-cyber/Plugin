package com.lumorasmp.cyscombat;

import org.bukkit.plugin.java.JavaPlugin;

public final class CysCombat extends JavaPlugin {

    private CombatListener combatListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        combatListener = new CombatListener(this);
        getServer().getPluginManager().registerEvents(combatListener, this);

        if (getCommand("cyscombat") != null) {
            getCommand("cyscombat").setExecutor(new ReloadCommand(this));
        }

        getLogger().info("CysCombat enabled. Folia-supported: true");
    }

    @Override
    public void onDisable() {
        getLogger().info("CysCombat disabled.");
    }

    public CombatListener getCombatListener() {
        return combatListener;
    }
}
