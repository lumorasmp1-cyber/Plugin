package com.lumorasmp.cyscombat;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.logging.Level;

/**
 * Handles custom damage + knockback for End Crystal and Respawn Anchor explosions.
 *
 * Design notes (Folia-safety):
 * - EntityDamageEvent (and its subclasses) for a given entity are always invoked on
 *   the region thread that owns that entity, per Folia's documented event model.
 * - entity.setVelocity(...) is called synchronously within the event, which is safe
 *   because we are already executing on the correct region thread.
 * - We never schedule cross-region tasks, so no RegionScheduler/EntityScheduler is
 *   needed anywhere in this listener.
 *
 * Damage cause / event-type notes (verified against Bukkit/Paper API docs):
 * - End Crystal explosions fire EntityDamageByEntityEvent, with the damager entity
 *   being an EnderCrystal instance and cause == ENTITY_EXPLOSION.
 * - Respawn Anchor (and Bed) explosions do NOT have an entity damager - they fire
 *   EntityDamageByBlockEvent instead, with cause == BLOCK_EXPLOSION. Because the
 *   anchor block is already cleared by the time this event fires, we must read
 *   getDamagerBlockState() (a pre-removal snapshot) to get a valid source location,
 *   rather than getDamager() which may return an already-air block.
 * - We deliberately avoid Skript's "damage cause is X" condition entirely, since its
 *   own documentation describes damage-cause comparison support as rudimentary/limited.
 */
public class CombatListener implements Listener {

    private final CysCombat plugin;

    public CombatListener(CysCombat plugin) {
        this.plugin = plugin;
    }

    // ==========================================
    // END CRYSTAL DAMAGE (entity-based explosion)
    // ==========================================
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!isWorldEnabled(victim.getWorld())) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) return;
        if (!(event.getDamager() instanceof EnderCrystal crystal)) return;

        if (!plugin.getConfig().getBoolean("end-crystal.enabled", true)) return;

        double damage = plugin.getConfig().getDouble("end-crystal.damage", 14.0);
        double kbHorizontal = plugin.getConfig().getDouble("end-crystal.knockback-horizontal", 2.2);
        double kbVertical = plugin.getConfig().getDouble("end-crystal.knockback-vertical", 0.45);
        double kbVerticalLimit = plugin.getConfig().getDouble("end-crystal.knockback-vertical-limit", 0.8);

        event.setCancelled(true);

        Location source = crystal.getLocation();
        Location targetLoc = victim.getLocation();

        applyDamageAndKnockback(victim, damage, source, targetLoc, kbHorizontal, kbVertical, kbVerticalLimit);

        debug("Crystal explosion: dealt " + damage + " dmg to " + victim.getName() +
                " with kb-h=" + kbHorizontal + " kb-v=" + kbVertical);
    }

    // ==========================================
    // RESPAWN ANCHOR DAMAGE (block-based explosion)
    // ==========================================
    // Respawn Anchor (and Bed) explosions fire EntityDamageByBlockEvent, NOT a plain
    // EntityDamageEvent and NOT EntityDamageByEntityEvent (there is no entity damager,
    // since the anchor is a block). getDamager() on this event returns the Block, but
    // for explosions that block has ALREADY been cleared/removed by the time this event
    // fires - so we must use getDamagerBlockState() instead, which is a snapshot taken
    // before removal and still has a valid getLocation() AND getType().
    //
    // IMPORTANT: TNT explosions also produce cause == BLOCK_EXPLOSION (same as anchors/beds).
    // We MUST check the actual block type via getDamagerBlockState().getType() to avoid
    // accidentally applying anchor damage/knockback to TNT explosion victims.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAnchorDamage(EntityDamageByBlockEvent event) {
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!isWorldEnabled(victim.getWorld())) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) return;

        BlockState damagerState = null;
        try {
            damagerState = event.getDamagerBlockState();
        } catch (Throwable t) {
            debug("getDamagerBlockState() unavailable: " + t.getMessage());
        }

        // Strict check: only proceed if we can confirm this was actually a
        // respawn anchor (or bed) block, not TNT/other block explosions.
        Material sourceType = damagerState != null ? damagerState.getType() : null;
        boolean isAnchorOrBed = sourceType == Material.RESPAWN_ANCHOR
                || (sourceType != null && sourceType.name().endsWith("_BED"));

        if (!isAnchorOrBed) {
            debug("BLOCK_EXPLOSION ignored: source block type = " + sourceType + " (not anchor/bed)");
            return;
        }

        if (!plugin.getConfig().getBoolean("respawn-anchor.enabled", true)) return;

        double damage = plugin.getConfig().getDouble("respawn-anchor.damage", 16.0);
        double kbHorizontal = plugin.getConfig().getDouble("respawn-anchor.knockback-horizontal", 2.4);
        double kbVertical = plugin.getConfig().getDouble("respawn-anchor.knockback-vertical", 0.45);
        double kbVerticalLimit = plugin.getConfig().getDouble("respawn-anchor.knockback-vertical-limit", 0.8);

        event.setCancelled(true);

        Location source = resolveAnchorSourceLocation(event, damagerState, victim);
        Location targetLoc = victim.getLocation();

        applyDamageAndKnockback(victim, damage, source, targetLoc, kbHorizontal, kbVertical, kbVerticalLimit);

        debug("Anchor/bed explosion: dealt " + damage + " dmg to " + victim.getName() +
                " with kb-h=" + kbHorizontal + " kb-v=" + kbVertical);
    }

    /**
     * Resolves the explosion origin location for a confirmed respawn anchor / bed explosion.
     * Priority order:
     *   1. The already-fetched damagerState snapshot location (most reliable).
     *   2. getDamager() block location, in case the server/fork still has it populated.
     *   3. DamageSource location, as a secondary fallback.
     *   4. Victim's own location (push straight up) as last resort, to avoid ever
     *      guessing a wrong horizontal direction.
     */
    private Location resolveAnchorSourceLocation(EntityDamageByBlockEvent event, BlockState damagerState,
                                                  LivingEntity victim) {
        if (damagerState != null) {
            return damagerState.getLocation();
        }

        try {
            if (event.getDamager() != null) {
                return event.getDamager().getLocation();
            }
        } catch (Throwable t) {
            debug("getDamager() block unavailable: " + t.getMessage());
        }

        try {
            if (event.getDamageSource() != null && event.getDamageSource().getLocation() != null) {
                return event.getDamageSource().getLocation();
            }
        } catch (Throwable t) {
            debug("DamageSource location unavailable: " + t.getMessage());
        }

        return victim.getLocation().clone();
    }

    // ==========================================
    // SHARED DAMAGE + KNOCKBACK LOGIC
    // ==========================================
    private void applyDamageAndKnockback(LivingEntity victim, double damage, Location source,
                                          Location targetLoc, double kbHorizontal,
                                          double kbVertical, double kbVerticalLimit) {

        // IMPORTANT: victim.damage(double) re-fires a NEW EntityDamageEvent internally
        // (with cause = CUSTOM). This is intentional here - it lets armor/enchantment/
        // resistance reductions apply normally, same as vanilla damage processing.
        // It does NOT cause infinite recursion because our listeners above only react
        // to cause == ENTITY_EXPLOSION or cause == BLOCK_EXPLOSION; a CUSTOM-cause event
        // will simply fall through both filters untouched.
        //
        // Reset noDamageTicks to 0 first: vanilla's hit-invulnerability window (normally
        // ~10 ticks after taking damage) would otherwise silently reduce or block this
        // damage if the victim was hit by something else moments earlier in the same combo.
        int previousNoDamageTicks = victim.getNoDamageTicks();
        victim.setNoDamageTicks(0);

        victim.damage(damage);

        // Restore a short invulnerability window afterward so this hit doesn't get
        // immediately re-triggered by a duplicate explosion tick in the same frame.
        victim.setNoDamageTicks(Math.max(previousNoDamageTicks, 10));

        // Reset velocity first to avoid double/stacking knockback from a prior hit
        // landing in the same tick.
        if (plugin.getConfig().getBoolean("reset-velocity-before-knockback", true)) {
            victim.setVelocity(new Vector(0, 0, 0));
        }

        Vector direction = targetLoc.toVector().subtract(source.toVector());

        // Guard against zero-length vector (victim standing exactly on the source location),
        // which would throw IllegalArgumentException on normalize().
        if (direction.lengthSquared() < 1.0E-6) {
            direction = new Vector(0, 0, 1); // arbitrary safe horizontal direction
        }

        // Normalize only the horizontal (X/Z) component for consistent horizontal knockback,
        // independent of vertical distance between source and victim.
        double dx = direction.getX();
        double dz = direction.getZ();
        double horizLength = Math.sqrt(dx * dx + dz * dz);

        Vector knockback;
        if (horizLength < 1.0E-6) {
            // Victim is directly above/below source; knockback is purely vertical.
            knockback = new Vector(0, 0, 0);
        } else {
            knockback = new Vector(
                    (dx / horizLength) * kbHorizontal,
                    0,
                    (dz / horizLength) * kbHorizontal
            );
        }

        double finalVertical = Math.min(kbVertical, kbVerticalLimit);
        knockback.setY(finalVertical);

        victim.setVelocity(knockback);
    }

    // ==========================================
    // WORLD FILTER
    // ==========================================
    private boolean isWorldEnabled(World world) {
        String mode = plugin.getConfig().getString("worlds.mode", "blacklist");
        List<String> list = plugin.getConfig().getStringList("worlds.list");

        if (list.isEmpty()) return true;

        boolean inList = list.contains(world.getName());
        if (mode.equalsIgnoreCase("whitelist")) {
            return inList;
        } else {
            return !inList;
        }
    }

    private void debug(String message) {
        if (plugin.getConfig().getBoolean("debug", false)) {
            plugin.getLogger().log(Level.INFO, "[Debug] " + message);
        }
    }
}
